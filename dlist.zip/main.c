
#include "slist.h"
#include "dlist.h"
//-------------------------------------------------
int main(int argc, const char* argv[]) {
  slist_test();
  dlist_test();

  return 0;
}
